# Quantum ISO - Starter project

This repository provides a **starter kit** for building a minimal custom Linux Live ISO ("Quantum ISO").
It's intended to run on a Debian/Ubuntu build host with root privileges and the following tools installed:

- `debootstrap`, `chroot`, `schroot` or `systemd-nspawn` (for creating chroots)
- `mksquashfs` (from squashfs-tools)
- `xorriso` (or `mkisofs`/`genisoimage`) to create hybrid ISO images
- `grub-pc-bin` and `grub-efi-amd64-bin` (for creating bootable ISOs supporting BIOS+UEFI)
- `rsync`, `sudo`, `bash`, `curl`/`wget`

High-level steps the included `build.sh` automates:
1. Create a chroot with `debootstrap` (Debian base)
2. Enter chroot and install packages from `config.packages`
3. Clean up, create a squashfs compressed filesystem
4. Assemble boot files and kernel/initramfs
5. Use `xorriso` to create a hybrid BIOS+UEFI bootable ISO

**Important:** This starter kit is a template. You will need to adapt kernel selection, initramfs generation,
and bootloader configuration to your needs. Always test ISOs in a VM (VirtualBox/QEMU) first.

## Files
- `build.sh` — main script to orchestrate the build (run as root on a Debian/Ubuntu host)
- `chroot-bootstrap.sh` — helper that runs inside the chroot to install packages and clean up
- `config.packages` — a sample list of packages to include
- `isolinux/` and `grub/` placeholders — bootloader config templates to be customized

## Usage example (on build host)

```bash
sudo bash build.sh --workdir /tmp/quantumiso --suite bookworm --arch amd64
```

The script will create `${WORKDIR}/iso` and produce `quantum-<suite>-<arch>.iso`.

## References
The script is inspired by Debian's live-build workflow, Minimal Linux Live and common ISO assembly commands.
See Debian Live manual: https://live-team.pages.debian.net/live-manual/
